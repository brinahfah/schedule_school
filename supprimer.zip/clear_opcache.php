<?php
/*if (function_exists('opcache_reset')) {
    opcache_reset();
    echo "OPcache vidé avec succès.";
} else {
    echo "OPcache n'est pas activé ou la fonction opcache_reset n'est pas disponible.";
}
*/
?>