<?php

return[
    'user' => 'postgres.mtamvxsqjgqieeciyhjh' ,  // Nom d'utilisateur // Nom de la base
    'password'=> 'brinahfah23' , //Mot de passe  
    'host' => 'aws-0-eu-west-3.pooler.supabase.com' ,  // Hôte de votre base
    'port' => '6543',  // Port PostgreSQL 
    'dbname' => 'postgres',  // Nom de la base 
];
?>